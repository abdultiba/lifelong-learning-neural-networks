from utilities.models import MultitaskMaskLinear, MultitaskMaskLinearV2

## Functions for Multitask Model Management

# Define a function to set the current task for each multitask module in the model
def set_model_task(model, task, verbose=True):
    # Loop over all named modules of the model
    for n, m in model.named_modules():
        # If the module is a multitask linear layer
        if isinstance(m, MultitaskMaskLinear) or isinstance(m, MultitaskMaskLinearV2):
            # If verbose, print a message indicating the task change
            if verbose:
                print(f"=> Set task of {n} to {task}")
            # Set the task attribute of the module to the given task
            m.task = task



# Define a function to cache the masks for each multitask module in the model
def cache_masks(model):
    # Loop over all named modules of the model
    for n, m in model.named_modules():
        # If the module is a multitask linear layer
        if isinstance(m, MultitaskMaskLinear) or isinstance(m, MultitaskMaskLinearV2):
            # Print a message indicating that the mask state is being cached
            print(f"=> Caching mask state for {n}")
            # Cache the mask state
            m.cache_masks()


# Define a function to set the number of tasks learned for each multitask module in the model
def set_num_tasks_learned(model, num_tasks_learned):
    # Loop over all named modules of the model
    for n, m in model.named_modules():
        # If the module is a multitask linear layer
        if isinstance(m, MultitaskMaskLinear) or isinstance(m, MultitaskMaskLinearV2):
            # Print a message indicating the change in learned tasks
            print(f"=> Setting learned tasks of {n} to {num_tasks_learned}")
            # Set the number of tasks learned attribute of the module
            m.num_tasks_learned = num_tasks_learned