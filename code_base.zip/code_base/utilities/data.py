import os
import copy
import glob
import torch
import random
import torchvision
import numpy as np
import pandas as pd
import seaborn as sns
from PIL import Image
import torchvision.transforms
import matplotlib.pyplot as plt
from collections import Counter
from torchvision import datasets, transforms

## Original MNIST  

class MNIST:
    # Constructor of MNIST class
    def __init__(self):
        super(MNIST, self).__init__()

        # Define the root path for the MNIST data
        data_root = "mnist"

        # Load the MNIST dataset for training, perform transformations on the dataset
        self.train_dataset = torchvision.datasets.MNIST(
            data_root,
            train=True,
            download=True,
            transform=torchvision.transforms.Compose(
                [
                    torchvision.transforms.ToTensor(),
                    torchvision.transforms.Normalize((0.1307,), (0.3081,)),
                ]
            ),
        )

        # Load training data in batches and shuffle it
        self.train_loader = torch.utils.data.DataLoader(
            self.train_dataset, batch_size=128, shuffle=True
        )

        # Load validation data in batches without shuffling
        self.val_loader = torch.utils.data.DataLoader(
            torchvision.datasets.MNIST(
                data_root,
                train=False,
                transform=torchvision.transforms.Compose(
                    [
                        torchvision.transforms.ToTensor(),
                        torchvision.transforms.Normalize((0.1307,), (0.3081,)),
                    ]
                ),
            ),
            batch_size=128,
            shuffle=False,
        )
        
    def summary(self):
        print(f'Train dataset size: {len(self.train_dataset)}')
        print(f'Validation dataset size: {len(self.val_loader.dataset)}')
        print(f'Training batches: {len(self.train_loader)}')
        print(f'Validation batches: {len(self.val_loader)}')
        print(f'Batch size: {self.train_loader.batch_size}')
        
    def compute_class_counts(self):
        train_class_counts = Counter()
        val_class_counts = Counter()

        # Compute training class counts
        for _, labels in self.train_loader:
            train_class_counts.update(labels.numpy())

        # Compute validation class counts
        for _, labels in self.val_loader:
            val_class_counts.update(labels.numpy())

        return dict(train_class_counts), dict(val_class_counts)







## Permuted MNIST

class MNISTPerm:
    # Inner class permute that implements the functionality of random permutation on tensors
    class permute(object):
        # Constructor for the inner class permute
        def __init__(self):
            # Initialise the permutation to the identity permutation
            self.perm = np.arange(784)

        # Callable function to flatten the tensor, perform permutation, and reshape it
        def __call__(self, tensor):
            out = tensor.flatten()
            out = out[self.perm]
            return out.view(1, 28, 28)

        # Represent the class as its name
        def __repr__(self):
            return self.__class__.__name__

    # Constructor of MNISTPerm class
    def __init__(self, seed=0):
        super(MNISTPerm, self).__init__()

        # Define the root path for the MNIST data
        data_root = "mnist"

        # Create an instance of the inner class permute
        self.permuter = self.permute()

        # Initialise the random seed
        self.seed = seed

        # Load the MNIST dataset for training, perform transformations on the dataset
        train_dataset = torchvision.datasets.MNIST(
            data_root,
            train=True,
            download=True,
            transform=torchvision.transforms.Compose(
                [
                    torchvision.transforms.ToTensor(),
                    torchvision.transforms.Normalize((0.1307,), (0.3081,)),
                    self.permuter,
                ]
            ),
        )

        # Load training data in batches and shuffle it
        self.train_loader = torch.utils.data.DataLoader(
            train_dataset, batch_size=128, shuffle=True
        )

        # Load validation data in batches without shuffling
        self.val_loader = torch.utils.data.DataLoader(
            torchvision.datasets.MNIST(
                data_root,
                train=False,
                transform=torchvision.transforms.Compose(
                    [
                        torchvision.transforms.ToTensor(),
                        torchvision.transforms.Normalize((0.1307,), (0.3081,)),
                        self.permuter,
                    ]
                ),
            ),
            batch_size=128,
            shuffle=False,
        )

    # Function to update the permutation for a task based on the task id and the seed
    def update_task(self, i):
        np.random.seed(i + self.seed)
        self.permuter.__setattr__("perm", np.random.permutation(784))

    # Function to reset the permutation to the original order
    def unpermute(self):
        self.permuter.__setattr__("perm", np.arange(784))
        

        
        
        
        
## Rotated MNIST



class Rotate(object):
    # Defines a callable object for rotating an image
    def __init__(self, angle=90):
        # Initialise with a default rotation angle of 90 degrees
        self.angle = angle

    def __call__(self, img):
        # Rotates the given image by self.angle degrees
        out = transforms.functional.rotate(img, self.angle)
        return out

    def __repr__(self):
        # Returns a string representation of the Rotate class
        return self.__class__.__name__ + '(angle={})'.format(self.angle)


class RotatingMNIST:
    # A class for loading and rotating MNIST data
    def __init__(self):
        # Initialise the class, creates the data loaders for MNIST dataset
        super(RotatingMNIST, self).__init__()

        data_root = "mnist"

        self.rotater = Rotate()

        # Define the transformations applied to the training dataset
        train_dataset = datasets.MNIST(
            data_root,
            train=True,
            download=True,
            transform=transforms.Compose(
                [
                    transforms.Grayscale(3),
                    self.rotater,
                    transforms.Grayscale(1),
                    transforms.ToTensor(),
                    transforms.Normalize((0.1307,), (0.3081,)),
                ]
            ),
        )

        # Create data loaders for the training and validation datasets
        kwargs = {}
        self.train_loader = torch.utils.data.DataLoader(
            train_dataset, batch_size=128, shuffle=True, **kwargs
        )
        self.val_loader = torch.utils.data.DataLoader(
            datasets.MNIST(
                data_root,
                train=False,
                transform=transforms.Compose(
                    [
                        transforms.Grayscale(3),
                        self.rotater,
                        transforms.Grayscale(1),
                        transforms.ToTensor(),
                        transforms.Normalize((0.1307,), (0.3081,)),
                    ]
                ),
            ),
            batch_size=128,
            shuffle=True,
            **kwargs,
        )

    def update_task(self, i):
        # Update the rotation angle attribute of the rotater instance
        self.rotater.__setattr__("angle", random.randint(0, 360))
        
        
        
        

## Partitioned MNIST

# Function to partition a dataset based on the given label pair
def partition_dataset(dataset, label_pair):
    newdataset = copy.copy(dataset)

    # Filter the data to only include images with the specified labels
    newdataset.data = [
        im
        for im, label in zip(newdataset.data, newdataset.targets)
        if label == torch.tensor(label_pair[0]) or label == torch.tensor(label_pair[1])
    ]

    # Similarly, filter the targets to only include the specified labels
    newdataset.targets = [
        label
        for label in newdataset.targets
        if label == torch.tensor(label_pair[0]) or label == torch.tensor(label_pair[1])
    ]

    return newdataset

# Class to handle the partitioned MNIST dataset
class PartitionMNIST:
    def __init__(self):
        super(PartitionMNIST, self).__init__()
        data_root = "mnist"

        # Label combinations for the 10 tasks
        label_pairs = [(0, 1), (2, 3), (4, 5), (6, 7), (8, 9), (0, 2), (1, 3), (4, 6), (5, 8), (7, 9)]

        # Load the training dataset with transformations
        train_dataset = datasets.MNIST(
            data_root,
            train=True,
            download=True,
            transform=transforms.Compose(
                [transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))]
            ),
        )

        # Load the validation dataset with transformations
        val_dataset = datasets.MNIST(
            data_root,
            train=False,
            transform=transforms.Compose(
                [transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))]
            ),
        )

        # Partition both training and validation dataset into 10 pairs,
        # based on the specified label combinations
        splits = [
            (
                partition_dataset(train_dataset, label_pair),
                partition_dataset(val_dataset, label_pair),
            )
            for label_pair in label_pairs
        ]

        # Print the length of the data in each split
        for i in range(10):
            print(len(splits[i][0].data))
            print(len(splits[i][1].data))
            print("==")

        kwargs = {}

        # Create data loaders for each of the splits with a batch size of 128
        self.loaders = [
            (
                torch.utils.data.DataLoader(
                    x[0], batch_size=128, shuffle=True, **kwargs
                ),
                torch.utils.data.DataLoader(
                    x[1], batch_size=128, shuffle=True, **kwargs
                ),
            )
            for x in splits
        ]

    # Method to update the current task. Sets the train_loader and val_loader 
    # to the loaders for the given task
    def update_task(self, i):
        self.train_loader = self.loaders[i][0]
        self.val_loader = self.loaders[i][1]